//
//  File.swift
//  BatikQuiz_SSC2022
//
//  Created by Catharina Adinda Mega Cahyani on 20/04/22.
//

#Disclaimer: For better experience, please set the simulator to iPhone 13 and portrait orientation. 

#Story Telling

When you hear about my country, Indonesia, the first thing that comes to your mind is definitely Bali. But did you know that Indonesia is much more famous because of one of its most prominent heritage? Yes, I'm talking about Batik.

However, will it surprise you if I say that many Indonesian people, including my family, don't know the many motifs of Batik, even the one that they usually wear?

It is complete opposite, Indonesians were trying hard so that batik was not claimed by other countries even to register it with UNESCO and batik had been officially a cultural heritage belonging to Indonesia in 2009, but many of them cannot mention the name of the batik motif that they wear (but somehow they manage to know names of famous designer cloth brands).

Do I know names of batik motifs? Absolutely, yes. Thanks to my middle school, St. Mary II Malang Middle School, names of batik motifs were part of my Art and Culture subject and school exam. However, that was the last time I got lesson about Batik. After that, I never got any lessons about batik again and batik is now only limited to mandatory clothes to be used on certain college days and on certain formal events. Therefore, it’s losing its heritage value.

Here I am, as an Information System student, who is now able to build a computer program, want to make that important lesson happen. To be honest, I’m a newbie in Swift programming. I used to build project in Web Development and App Development (.NET). Actually, the concept doesn’t have much differences, but I need a time to learn new syntax and adapt with new IDE.  Therefore, I started learning Swift since January 2022 as preparation. Thankfully, I manage to build simple program like this quiz.

I choose quiz method in order to make the process of learning the names of batik motifs more exciting, simple, and challenging. It brings me back to my middle school where batik motifs were still highly valued at schools. Let’s learn the batik motifs once again.

#Tech and Features 
1. Swift UI Framework
2. Auto Layout : iPhone 13 and iPad Pro (12.9-inch)(5th generation) 
3. Adaptive Orientation: both Portrait and Landscape (Portrait is preferred)
4. Support Dark Mode
5. Auto Stroke Color Changes Animation: give the correct answer to user when the user choose the wrong answer
6. UIViewRepresentable: Convert Some of UIKit Component 


 
#Assets and Resources
1. Game Console Logo: made by myself using Adobe Photoshop
2. Memoji AR Apple Official (saved in .png)
3. All Batik Images and Description: There are already references shown in every question pages as an image caption. All of the batik images are being in the Public Domain.

#Beyond WWDC 2022
As Information Systems Student, I already build programs in VB.NET, PHP, and Python. I usually use MySQL and Microsoft SQL Server as tool for my Database Management System. My past internship experiences are  Web Developer Internship at Campuspedia, Data Scientist Internship at PT. KCG (official Charles & Keith, Pedro, and Emporio Armani 7 retailer in Indonesia), and iOS Mobile Developer Internship at Telkom Direktorat Digital Business. Now, I'm working as tech intern at Apple Academy Developer @UC. I once participated and finished on their program called Apple Foundation 2019. I still don't know which programming learning path I should choose. Therefore, I'm planning to apply master degree's scholarship.
